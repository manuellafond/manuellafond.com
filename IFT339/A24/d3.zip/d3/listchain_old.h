/*
 * VOTRE EN-T�TE ICI!
 * Vous pouvez fournir vos r�ponses en texte ici.
 */


#ifndef TP3_LISTCHAIN_H
#define TP3_LISTCHAIN_H


#include <iostream>


 /**
  * Classe pour une structure de donn�es de liste cha�n�e de listes cha�n�es.
  */
template <typename TYPE>
class listchain
{
private:

    //Repr�sente un noeud conteneur d'�l�ments
    struct Noeud {
        TYPE val;
        Noeud* next;

        Noeud() {
            next = nullptr;
        }
    };

    //Repr�sente une cha�ne de noeuds.
    struct SuperNoeud
    {
        Noeud* premier_noeud;
        Noeud* dernier_noeud;

        SuperNoeud* prev;
        SuperNoeud* next;
        size_t nbelem;      //nombre d'�l�ments dans la cha�ne du super noeud

        SuperNoeud() {
            premier_noeud = dernier_noeud = nullptr;
            prev = next = nullptr;
            nbelem = 0;
        }
    };

    SuperNoeud* debut;   //premier super noeud, ou nullptr si la liste est vide
    SuperNoeud* fin;     //dernier super noeud, ou nullptr si la liste est vide
    size_t max_taille;   //nombre d'�l�ment maximum qu'un super noeud peut contenir

public:

    listchain() : listchain(10) {};	//redirige vers l'autre constructeur avec max_taille = 10

    listchain(size_t max_taille_supernoeud);	//construit en sp�cifiant max_taille

    ~listchain();

    listchain(const listchain& source);

    listchain& operator=(const listchain& source);


    TYPE& operator[](size_t i);

    size_t size() const;

    void push_front(const TYPE& val);
    void push_back(const TYPE& val);
    void pop_front();
    void pop_back();


    //*** J'ai pens� demander le insert_at et le erase_at, mais concentrez-vous sur l'intra � la place
    //*** Vous pouvez quand m�me r�fl�chir � comment vous l'auriez impl�ment�
    //void erase_at(const size_t pos);
    //void insert_at(const size_t pos, const TYPE& val);

    void clear();	//remet la liste vide


    void afficher_contenu();    //Affiche le contenu avec une ligne par sous-tableau.  

};





/*------------------------------------------------------------------------------
IMPL�MENTATION
------------------------------------------------------------------------------*/





/**
 * Constructeur qui initialise avec une liste vide.
 * tabsize est la taille des sous-tableaux
 */
template <typename TYPE>
listchain<TYPE>::listchain(size_t max_taille_supernoeud)
{
    //impl�mentez-moi


}




/**
 * Destructeur qui d�salloue toute la m�moire et nettoie
 */
template <typename TYPE>
listchain<TYPE>::~listchain()
{
    //impl�mentez-moi

}







/**
 * Supprime tous les �l�ments et remet � l'�tat d'une liste vide.
 */
template <typename TYPE>
void listchain<TYPE>::clear()
{
    //impl�mentez-moi

    
}


/**
 * Constructeur par copie: met la liste � vide et d�l�gue tout � l'op�rateur =
 */
template <typename TYPE>
listchain<TYPE>::listchain(const listchain& source)
{
    //impl�mentez-moi

    
}


/**
 * Op�rateur =
 * Nettoie l'objet courant et copie tout de la source
 */
template <typename TYPE>
listchain<TYPE>& listchain<TYPE>::operator=(const listchain& src)
{
    //impl�mentez-moi
    //NOTE: puisque vous n'avez pas � recopier exactement les m�mes super noeuds 
    //Il faut juste que le contenu soit le m�me, mais pas n�cessairement les nbelem des super noeuds.
	//Ceci devrait vous simplifier la t�che.

    

}



/**
 * Retourne le i-�me �l�ment.
 */
template <typename TYPE>
TYPE& listchain<TYPE>::operator[](size_t i)
{
    //impl�mentez-moi
    //aucune v�rification de borne � faire

    
}



/**
 * Retourne le nombre d'�l�ments dans votre liste.
 */
template <typename TYPE>
size_t listchain<TYPE>::size() const
{
    //impl�mentez moi

    
}



/**
 * Ajouter en d�but de liste.  Ins�rer une nouvelle cellule au d�but si n�cessaire.
 */
template <typename TYPE>
void listchain<TYPE>::push_front(const TYPE& val)
{
    //impl�mentez moi
    //N'oubliez pas de maintenir les nbelem ( je le dis car j'oubliais toujours :P )

    
}

/**
 * Ajouter en fin de liste.  Ajouter une nouvelle cellule � la fin si n�cessaire.
 */
template <typename TYPE>
void listchain<TYPE>::push_back(const TYPE& val)
{
    //impl�mentez-moi
    
}










/**
 * Enl�ve l'�l�ment en t�te de liste.  Ne v�rifie rien.
 */
template <typename TYPE>
void listchain<TYPE>::pop_front()
{
    //impl�mentez-moi

    
}


/**
 * Enl�ve l'�l�ment en fin de liste.  Ne v�rifie rien.
 */
template <typename TYPE>
void listchain<TYPE>::pop_back()
{
	//je le fais pour vous 
	
    if (!fin)   //liste vide
        return;

    //cas 1: le dernier super noeud a un seul element -> il va dispara�tre
    if (fin->nbelem == 1) {
        delete fin->premier_noeud;	//le premier est aussi le dernier

        SuperNoeud* finprev = fin->prev;
        delete fin;
        fin = finprev;

        
        if (!finprev)   //si on vient de supprimer le dernier super noeud
            debut = nullptr;
        else
            fin->next = nullptr;
    }
    //cas 2: on doit supprimer le dernier elt de fin.  
	//On est oblig� de boucler pour aller chercher l'avant-dernier noeud de la sous-liste.
    else {
        Noeud* v_prev = fin->premier_noeud;
        Noeud* v = fin->premier_noeud->next;

        while (v->next) {
            v_prev = v;
            v = v->next;
        }
        delete v;
        v_prev->next = nullptr;

        fin->nbelem--;
    }

}


/**
 * Affiche le contenu avec une ligne par sous-tableau.  Un X veut dire "case non-utilis�e"
 */
template <typename TYPE>
void listchain<TYPE>::afficher_contenu()
{
    std::cout << "-------------------------------------" << std::endl;
    std::cout << "size() = " << size() << std::endl;

    SuperNoeud* sn = debut;
    while (sn) {

        std::cout << "[" << sn->nbelem << "] ";
        Noeud* v = sn->premier_noeud;
        while (v) {
            std::cout << v->val << " ";
            v = v->next;
        }
        std::cout << std::endl;

        sn = sn->next;
    }

}



#endif //TP3_LISTCHAIN_H
