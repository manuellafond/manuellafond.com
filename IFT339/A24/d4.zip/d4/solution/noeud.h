#ifndef TP4_NOEUD_H
#define TP4_NOEUD_H

#include <vector>
#include <iostream>


template <typename TYPE>
class Noeud{
private:
    TYPE valeur;                            //valeur associ�e au Noeud
    Noeud* parent;                       //parent du Noeud, possiblement nullptr
    std::vector<Noeud*> enfants;              //liste des enfants du Noeud

    //Vous pouvez ajouter des fonctions priv�es, au besoin - mais PAS de fonctions publiques ni de variable membre

public:

    class iterator;
    friend class Noeud::iterator;				//pour que l'it�rateur ait acc�s � la section priv�e de Noeud

    Noeud(const TYPE& valeur);                     // constructeur principal prenant la valeur associ�e au Noeud
    Noeud(const Noeud& source);                 // constructeur par copie
    ~Noeud();                                   // destructeur

    Noeud& operator=(const Noeud& source);      // affectateur (copie de la source)


    TYPE& val();                           		// retourne une r�f�rence MODIFIABLE vers la valeur associ�e au Noeud.
    Noeud* get_enfant(size_t i);				// retourne le i-�me enfant (le premier est indic� � 0)
    size_t get_nb_enfants() const;				// retourne le nombre d'enfants du Noeud
    Noeud* ajouter_enfant(const TYPE& valeur);		// cr�� un enfant ajout� � la fin de la liste d'enfants, et le retourne
    void supprimer_enfant(size_t i);            //supprime tout le sous-arbre enracin� en le i-�me enfant.  


    iterator begin();                            // retourne un it�rateur postordre sur l'arbre
    iterator end();                              // retourne l'it�rateur pointant sur la fin (et la fin n'est PAS un �l�ment)

    void afficher_postordre() const;             // fait un parcours postordre R�CURSIF en affichant les valeurs dans l'ordre.  Pour tester.

};





//D�claration de la classe it�rateur.
template <typename TYPE>
class Noeud<TYPE>::iterator{
private:

    //� vous de choisir une repr�sentation de l'it�rateur � l'aide de variables membres

    //ML
    Noeud* racine;
    Noeud* curnoeud;
    bool estfin;
    ///ML

public:

    //� ajouter: constructeurs, destructeur, constructeur par copie (au besoin)
    //ML

    iterator(Noeud* racine, Noeud* n, bool estFin){
        this->curnoeud = n;
        this->racine = racine;
        this->estfin = estFin;
    }
    ///ML

    iterator& operator++();                       // incr�mente l'it�rateur.
    iterator operator++(int i);                  // incr�mente l'it�rateur.  Le param�tre i est inutile.
    iterator& operator--();                       // d�cr�mente l'it�rateur.
    iterator operator--(int i);                  // d�cr�mente l'it�rateur.  Le param�tre i est inutile.

    TYPE& operator*();                           // retourne la valeur associ�e au noeud point� par l'it�rateur
    bool operator==(const iterator& it);  // v�rifie si l'it�rateur est �gal � it
    bool operator!=(const iterator& it);  // v�rifie si l'it�rateur est diff�rent de it
};




/********************************************************
Impl�mentation de la classe Noeud
********************************************************/


/**
 * Constructeur principal de Noeud.  val est la valeur associ�e au Noeud
 * � la construction, le parent est nullptr.
 */
template <typename TYPE>
Noeud<TYPE>::Noeud(const TYPE& valeur){
    this->valeur = valeur;
    this->parent = nullptr;
}

/**
 * Constructeur par copie.  On doit copier toute la structure.
 */
template <typename TYPE>
Noeud<TYPE>::Noeud(const Noeud& source){
    *this = source;
}



/**
Affectateur =.  this devient une copie de source.
**/
template <typename TYPE>
Noeud<TYPE>& Noeud<TYPE>::operator=(const Noeud& source) {
    if (this == &source)
        return *this;

    this->valeur = source.valeur;
    for (size_t i = 0; i < source.get_nb_enfants(); i++){
        Noeud* enfant = new Noeud(*(source.enfants[i]));
        enfant->parent = this;
        this->enfants.push_back(enfant);
    }

    return *this;
}



/**
 * Destructeur.  Chaque est responsable de supprimer ses enfants.
 */
template <typename TYPE>
Noeud<TYPE>::~Noeud(){
    for (size_t i = 0; i < enfants.size(); i++){
        delete enfants[i];  //entra�ne une chaine de suppression chez les descendants
    }
    //question de r�flexion: pourquoi on ne delete pas this?  Comment la racine va-t-elle se supprimer?
}



/**
 * Ajoute un enfant � la fin de la liste d'enfants, et le retourne.
 * val est la valeur associ�e au nouveau Noeud.
 * Le parent du nouveau Noeud est affect� au Noeud courant.
 */
template <typename TYPE>
Noeud<TYPE>* Noeud<TYPE>::ajouter_enfant(const TYPE& valeur){
    Noeud* n = new Noeud(valeur);
    n->parent = this;
    this->enfants.push_back(n);
    return n;
}




/**
 * Retourne une r�f�rence sur la valeur associ�e au Noeud.  On peut ensuite modifier val.
 */
template <typename TYPE>
TYPE& Noeud<TYPE>::val(){
    return valeur;
}






/**
 * Retourne le nombre d'enfants du Noeud.
 */
template <typename TYPE>
size_t Noeud<TYPE>::get_nb_enfants() const{
    return enfants.size();
}

/**
 * Retourne le i-�me enfant (le premier est indic� � 0).
 * C'est du C++, donc on ne fait aucune v�rification.
 */
template <typename TYPE>
Noeud<TYPE>* Noeud<TYPE>::get_enfant(size_t i){
    return enfants[i];
}




/**
Supprime tout le sous - arbre enracin� en le i - �me enfant.
*/
template <typename TYPE>
void Noeud<TYPE>::supprimer_enfant(size_t i) {
    delete enfants[i];

    enfants.erase(enfants.begin() + i);
}




template <typename TYPE>
void Noeud<TYPE>::afficher_postordre() const{
    for (size_t i = 0; i < enfants.size(); i++){
        enfants[i]->afficher_postordre();
    }

    std::cout << valeur << " ";
}






/**
 * Retourne le d�but un it�rateur postordre sur l'arbre.
 * Le d�but devrait donc pointer sur le noeud le plus "� gauche".
 */
template <typename TYPE>
typename Noeud<TYPE>::iterator Noeud<TYPE>::begin(){
    //ML
    Noeud* plus_gauche = this;
    while (plus_gauche->enfants.size() > 0){
        plus_gauche = plus_gauche->enfants[0];
    }


    return Noeud::iterator(this, plus_gauche, false);
    ///ML
}

/**
 * Retourne un it�rateur repr�sentant la fin de l'arbre.
 * La fin n'est pas la m�me chose que le dernier �l�ment.
 */
template <typename TYPE>
typename Noeud<TYPE>::iterator Noeud<TYPE>::end(){
    //ML
    return iterator(this, this, true);
    ///ML
}



template <typename TYPE>
typename Noeud<TYPE>::iterator Noeud<TYPE>::iterator::operator++(int i){
    iterator tmp = *this;
    ++(*this);
    return tmp;
}




/**
 * Incr�mente l'it�rateur.  Le comportement est non-d�fini si l'it�rateur est �gal � end()
 */
template <typename TYPE>
typename Noeud<TYPE>::iterator& Noeud<TYPE>::iterator::operator++(){
    //impl�mentez-moi
    //L'�tat interne de l'it�rateur DOIT �tre modifi�.

    //ML

    if (racine == curnoeud && !estfin)
    {
        estfin = true;
    }
    else
    {
        size_t monindice = 0;
        for (size_t i = 0; i < curnoeud->parent->enfants.size(); i++)
        {
            if (curnoeud->parent->enfants[i] == curnoeud)
            {
                monindice = i;
                break;
            }
        }

        if (monindice == curnoeud->parent->get_nb_enfants() - 1)
        {
            curnoeud = curnoeud->parent;
        }
        else
        {
            curnoeud = curnoeud->parent->enfants[monindice + 1];
            while (curnoeud->enfants.size() > 0)
            {
                curnoeud = curnoeud->enfants[0];
            }
        }
    }


    return (*this);
    ///
}





template <typename TYPE>
typename Noeud<TYPE>::iterator Noeud<TYPE>::iterator::operator--(int i){
    iterator tmp = *this;
    --(*this);
    return tmp;
}


/**
 * D�cr�mente l'it�rateur.  Le comportement est non-d�fini si l'it�rateur est begin().
 * Lorsque l'on fait
 * noeud::iterator it = n->end();
 * it--;
 * on s'attend � ce que it point sur n.
 */
template <typename TYPE>
typename Noeud<TYPE>::iterator& Noeud<TYPE>::iterator::operator--(){
    //impl�mentez-moi


    //ML
    if (estfin){
        estfin = false;
    }
    else if (curnoeud->enfants.size() > 0){
        curnoeud = curnoeud->enfants[curnoeud->enfants.size() - 1];
    }
    else{
        //retrouver le premier anc�tre qui a un voisin gauche
        while (curnoeud == curnoeud->parent->enfants[0]){
            curnoeud = curnoeud->parent;
        }

        //TODO: CODE DUPLIQU�!!!  (je fais expr�s de le laisser ici pour vous)
        size_t monindice = 0;
        for (size_t i = 0; i <curnoeud->parent->enfants.size(); i++){
            if (curnoeud->parent->enfants[i] == curnoeud){
                monindice = i;
                break;
            }
        }

        curnoeud = curnoeud->parent->enfants[monindice - 1];

    }


    return (*this);
    ///ML
}



template <typename TYPE>
TYPE& Noeud<TYPE>::iterator::operator*(){
    //impl�mentez-moi

    //ML
    return curnoeud->valeur;
    ///ML
}



/**
 * Compare l'it�rateur avec un autre.
 * La comparaison avec end() doit bien fonctionner.
 * On d�finit que deux it�rateurs sur deux arbres ou sous-arbres diff�rents ne peuvent
 * jamais �tre �gaux.
 */
template <typename TYPE>
bool Noeud<TYPE>::iterator::operator==(const iterator& it){
    //impl�mentez-moi!

    //ML
    if (racine != it.racine)
        return false;

    if (estfin){
        return it.estfin;
    }
    else{
        return (curnoeud == it.curnoeud && !it.estfin);
    }
    ///ML
}



/**
 * Compare l'it�rateur avec un autre, et retourne true s'ils sont diff�rents.
 * La comparaison avec end() doit bien fonctionner.
 * On d�finit que deux it�rateurs sur deux arbres ou sous-arbres diff�rents ne peuvent
 * jamais �tre �gaux.
 */
template <typename TYPE>
bool Noeud<TYPE>::iterator::operator!=(const iterator &it){
    return !( (*this) == it );
}





#endif //TP4_NOEUD_H
