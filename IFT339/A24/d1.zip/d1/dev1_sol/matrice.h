#ifndef MATRICE_H
#define MATRICE_H


#include <stddef.h> //pour size_t
#include <iostream>
#include <vector>

using namespace std;

/**
 * Repr�sentation d'une matrice � l'iade d'un pointeur de pointeurs
 * @tparam TYPE Type d'objet � stocker
 */
template <typename TYPE>
class Matrice
{
private:
    TYPE** tab;
    size_t nb_rangees;
    size_t nb_colonnes;


    //ajout ML
    void clean() {
        if (tab) {		//ne fait pas ces op�rations si tab est vide
            for (size_t i = 0; i < nb_rangees; i++)
            {
                delete[] tab[i];	//Supprime les rang�es
            }
            delete[] tab;			//Supprime les colonnes
            tab = nullptr;			//Assigne tab au pointeur null
        }
    }

public:

    /**
     * Constructeur qui re�oit le nombre de rang�es et de colonne.  La matrice construite doit contenir n * m cellules,
     * chacune contenant une valeur de type TYPE non-initialis�e.
     * @param n Nombre de rang�es
     * @param m Nombre de colonnes
     */
    Matrice(size_t n, size_t m);






    /**
     * Constructeur qui re�oit le nombre de rang�es et de colonne, en plus des valeurs des cellules sous la forme d'un vector.
     * Les m premi�res entr�es du vecteur sont les entr�es de la rang�e 1, les m entr�es suivantes les entr�es de la rang�e 2, et ainsi de suite.
     * @param n Nombre de rang�es
     * @param m Nombre de colonnes
     * @param v Contenu de la matrice
     */
    Matrice(size_t n, size_t m, vector<TYPE> v);







    /**
     * Constructeur par copie.  La matrice construite aura les m�me dimensions que src, et le contenu de chaque cellule
     * de src est copi� dans les cellules correspondantes.
     * @param src Matrice � copier.
     */
    Matrice(const Matrice& src);






    /**
     * Destructeur.
     */
    ~Matrice();


    /**
     * Surcharge de l'affectation.  Apr�s l'ex�cution, la matrice courante devient une copie de src.  Les �l�ments stock�s
     * dans l'objet courant avant la copie disparaissent.
     * @param src Matrice � assigner.
     * @return R�f�rence vers la matrice courante.
     */
    Matrice& operator=(const Matrice& src);








    




    /**
     * Retourne une r�f�rence vers l'objet � la rang�e r et � la colonne c.  Aucune v�rification n'est faite sur les bornes de r et c, 
     * c'est � l'appelant de s'assurer que r et c sont dans les dimensions de la matrice.
     * Puisqu'une r�f�rence est retourn�e, modifier l'objet retourn� doit aussi modifier l'objet de la matrice.
     * Par exemple, si m est une instance de Matrice<int>,
     * ma_matrice(2, 3) = 10;
     * place la valeur 10 � la troisi�me rang�e, quatri�me colonne.
     * @param r Indice de rang�e
     * @param c Indice de colonne
     * @return R�f�rence sur l'objet � la rang�e r, colonne c
     */
    TYPE& operator()(size_t r, size_t c);




    /**
     * Fait la m�me chose que l'op�rateur (r, c), mais v�rifie dans r et c sont dans les bornes de la matrice.
     * Si l'entr�e � la rang�e r et colonne c n'existe pas, une exception est lanc�e (via throw Exception("message");)
     * @param r Indice de rang�e
     * @param c Indice de colonne
     * @return R�f�rence sur l'objet � la rang�e r, colonne c
     */
    TYPE& at(size_t r, size_t c);







    /**
     * Affecte une nouvelle dimension � la matrice. Les �l�ments de la matrice actuelle (avant redimension) qui peuvent �tre 
     * conserv�s doivent �tre conserv�s.  Donc, s'il y pr�sentement un �l�ment � la rang�e i, colonne j, tel que i < n et j < m, 
     * cet �l�ment doit toujours �tre pr�sent apr�s redimensionnement, aux m�me positions.  Si i >= n ou i >= m, alors l'�l�ment disparait.
     *
     * @param n Nouveau nombre de rang�es
     * @param m Nouveau nombre de colonnes
     */
    void redimensionner(size_t n, size_t m);



    /**
     * Retourne les dimensions de la matrice
     * @return Une paire p telle que p.first = nombre de rang�es, et p.second = nombre de colonnes
     */
    pair<size_t, size_t> get_dimensions() const;




    /**
     * �change le contenu de la rang�e r1 avec le contenu de la rang�e r2
     * @param r1 Indice de la premi�re rang�e
     * @param r2 Indice de la deuxi�me rang�e
     */
    void swap_rangees(size_t r1, size_t r2);

    /**
     * �change le contenu de la colonne c1 avec le contenu de la colonne c2
     * @param c1 Indice de la premi�re colonne
     * @param c2 Indice de la deuxi�me colonne
     */
    void swap_colonnes(size_t c1, size_t c2);


    /**
     * Affiche de contenu de la matrice sur la sortie standard via cout.  Pour d�bogage.
     */
    void afficher();

};




//////////////////////////////////////////////////////////////////////////////////////////
// IMPL�MENTATION
//////////////////////////////////////////////////////////////////////////////////////////
template <typename TYPE>
Matrice<TYPE>::Matrice(size_t n, size_t m)
{
    tab = nullptr;
    nb_rangees = 0;
    nb_colonnes = 0;

    redimensionner(n, m);
}



template <typename TYPE>
Matrice<TYPE>::Matrice(size_t n, size_t m, vector<TYPE> v)
{
    tab = nullptr;
    nb_rangees = 0;
    nb_colonnes = 0;

    redimensionner(n, m);

    //� compl�ter
    for (size_t i = 0; i < v.size(); ++i) 
    {
        size_t row = i / nb_colonnes;
        size_t col = i % nb_colonnes;

        this->at(row, col) = v[i];
    }

}




template <typename TYPE>
Matrice<TYPE>::Matrice(const Matrice& src)
{
    *this = src;
}

template <typename TYPE>
Matrice<TYPE>::~Matrice()
{
    clean();
}



template <typename TYPE>
Matrice<TYPE>& Matrice<TYPE>::operator=(const Matrice& src)
{
    clean();


    redimensionner(src.nb_rangees, src.nb_colonnes);
    


    for (size_t i = 0; i < nb_rangees; i++)
    {
        for (size_t j = 0; j < nb_colonnes; j++)
        {
            tab[i][j] = src.tab[i][j];		//Assigne la valeur a la position (i,j) de src
            //a la position (i,j) de tab
        }
    }
    return *this;
}





template <typename TYPE>
TYPE& Matrice<TYPE>::operator()(size_t r, size_t c) {
    return tab[r][c];
}



template <typename TYPE>
TYPE& Matrice<TYPE>::at(size_t r, size_t c) {
    return tab[r][c];
}





template <typename TYPE>
void Matrice<TYPE>::redimensionner(size_t n, size_t m)
{
    TYPE** temp = new TYPE * [n];// Cr�e un pointeur de pointeur temp de taille nxm

    for (size_t i = 0; i < n; i++)
    {
        temp[i] = new TYPE[m];
    }


    if (tab) {		// Si le tableau pointe vers nullptr
        for (size_t i = 0; i < min(nb_rangees, n); i++)	// Assigne les valeurs de tableau temporaire au nouveau tableau
        {
            for (size_t j = 0; j < min(nb_colonnes, m); j++)
            {
                temp[i][j] = tab[i][j];
            }
        }

        clean();
    }

    tab = temp;	//R�assigne le pointeur de pointeur tableau au nouveau tableau de bonne dimension

    nb_rangees = n; //R�assigne le bon nombre de colonnes et de rang�es
    nb_colonnes = m;
}


template <typename TYPE>
pair<size_t, size_t> Matrice<TYPE>::get_dimensions() const
{
    return make_pair(nb_rangees, nb_colonnes);
}








template <typename TYPE>
void Matrice<TYPE>::swap_rangees(size_t r1, size_t r2) {
    TYPE* tmp = tab[r1];

    tab[r1] = tab[r2];
    tab[r2] = tmp;
}

template <typename TYPE>
void Matrice<TYPE>::swap_colonnes(size_t c1, size_t c2) {

    for (int r = 0; r < nb_rangees; ++r) {
        TYPE tmp = tab[r][c1];
        tab[r][c1] = tab[r][c2];
        tab[r][c2] = tmp;
    }
}




template <typename TYPE>
void Matrice<TYPE>::afficher() {
    for (size_t i = 0; i < nb_rangees; ++i) {
        for (size_t j = 0; j < nb_colonnes; ++j) {
            cout << this->at(i, j) << " ";
        }
        cout << endl;
    }
    cout << endl;
}





#endif
