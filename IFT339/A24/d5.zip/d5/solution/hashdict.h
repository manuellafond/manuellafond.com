#ifndef HASHDICT_H
#define HASHDICT_H

#include <cstddef>
#include <functional>



// Je mets mon nom et cip dans l'en-tête tel que demandé: Manuel Lafond - lafm3844
/*
Pardon pour la confusion dans les noms de fichier.  Mon main.cpp incluait hashdict_ml.h et 
l'énoncé demandait de remettre noeud.h.  Je n'ai pas revérifié suffisamment.  Je ne pénalisais pas 
la remise de mauvais noms de fichier.
*/


/*
Implémentation d'un dictionnaire avec une table de hachage.
On peut supposer que TYPECLE est hachable.  Ceci veut dire que vous pouvez transformer une clé
en une adresse entre 0 et cap avec le code
(hash<TYPECLE>()(cle) % cap)
*/
template <typename TYPECLE, typename TYPEVAL>
class hashdict {
private:

    struct alveole {
        TYPECLE cle;
        TYPEVAL val;

        alveole() {}

        alveole(const TYPECLE& cle, const TYPEVAL& val) {
            this->cle = cle;
            this->val = val;
        }
    };

    /*
     * table est un tableau de pointeurs d'alvéoles.  Il y a 3 cas pour un élément table[i]:
     * Si table[i] == nullptr, alors l'alvéole i est inutilisée.
     * Si table[i] == bidon, alors l'alvéole ne contient rien et est libre pour insertion, mais il y a déjà eu un élément qui a été supprimé.
     * Sinon, table[i] contient un élément utilisateur.
     */
    alveole** table;



    alveole* bidon;     //alvéole bidon, réutilisable à plusieurs endroits

    size_t cap;         //capacité de table
    size_t nbelem;      //nombre d'éléments utilisateur dans table


    /*
    Vous pouvez ajouter des fonctions privées, au besoin, mais pas de nouvelles variable.
    */

    /**
     * AJOUT: méthode privée pour trouver la position d'une clé.  Ceci permet d'éviter la répétition de la logique de 
     * recherche d'adresse, ce qui peut être utile si on veut changer le type d'adressage ouvert en faisait un pas différent.
     * Retourne la position de l'alvéole qui contient cle.  Si elle n'existe pas:
     *   - si arretSurBidon == false, retourne la première position qui contient nullptr après l'alvéole de la clé.
     *   - si arretSurBidon == true, retourne la première position qui contient nullptr OU bidon après l'alvéole de la clé.
     * Si vos fonctions inserer, contient_cle, operator[] sont longues, regardez l'impact de centraliser ceci en une seule fonction
     */
    size_t get_position_cle(const TYPECLE& cle, bool arretSurBidon = false) const;


    /*
        Réaffecte la capacité à c, en supprimant et recréant toute la table
    */
    void set_cap(size_t c);


public:

    hashdict();

    hashdict(const hashdict& src);

    hashdict& operator=(const hashdict& src);

    ~hashdict();

    /*
     * Supprime tous les éléments et met la capacité à une valeur par défaut
     */
    void clear();

    /*
     * Insère la clé et l'associe à val.  Retourne true s'il y a eu insertion, ou false si la clé était déjà présente
     */
    bool inserer(const TYPECLE& cle, const TYPEVAL& val);

    /*
     * Retourne true si la clé est présente, et false sinon
     */
    bool contient_cle(const TYPECLE& cle) const;

    /*
     * Supprime la clé.
     */
    bool supprimer(const TYPECLE& cle);

    /*
     * Retourne une référence vers la valeur associée à cle.  Si la clé est absente, elle sera d'abord insérée et associée
     * à une valeur créée par le constructeur par défaut.
     */
    TYPEVAL& operator[](const TYPECLE& cle);


    /*
     * Retourne le nombre d'éléments
     */
    size_t size();

};








template <typename TYPECLE, typename TYPEVAL>
hashdict<TYPECLE, TYPEVAL>::hashdict() {
    table = nullptr;
    bidon = new alveole();  //devrait toujours exister, supprimer à la destruction seulement
    cap = 0;
    set_cap(100);
    nbelem = 0;
}



template <typename TYPECLE, typename TYPEVAL>
hashdict<TYPECLE, TYPEVAL>::~hashdict() {
    
    //ceci répète le code de clear, mais comme je disais c'était acceptable.  
    //Une meilleure façon aurait été d'avoir une fonction privée de nettoyage 
    //avec un bool pour décider si on recréait une table ou non.
    if (table) {
        for (size_t i = 0; i < cap; i++) {
            if (table[i] && table[i] != bidon)
                delete table[i];
        }
        delete[] table;
    }

    delete bidon;
}



template <typename TYPECLE, typename TYPEVAL>
hashdict<TYPECLE, TYPEVAL>::hashdict(const hashdict& src) {
    //par clémence, je l'ai implémenté pour vous - vous pouvez modifier au besoin
    table = nullptr;
    bidon = new alveole();	//une alvéole arbitraire qui servira de bidon

    *this = src;
}


template <typename TYPECLE, typename TYPEVAL>
hashdict<TYPECLE, TYPEVAL>& hashdict<TYPECLE, TYPEVAL>::operator=(const hashdict& src) {

    //par clémence, je l'ai implémenté pour vous - vous pouvez modifier au besoin
    if (this == &src)
        return *this;

    if (table) {
        //exceptionnellement, si vous avez à répéter ce bout de code de nettoyage, ce sera toléré
        for (int i = 0; i < cap; ++i) {
            if (table[i] != bidon)  //j'ai ajouté cette ligne pour éviter des ennuis
                delete table[i];
        }
        delete[] table;
    }


    cap = src.cap;
    nbelem = src.nbelem;

    table = new alveole * [src.cap];	//créé un tableau de pointeurs
    for (size_t i = 0; i < src.cap; i++) {
        if (src.table[i] == src.bidon)
            table[i] = bidon;
        else if (src.table[i]) {
            alveole* alv = new alveole(src.table[i]->cle, src.table[i]->val);
            table[i] = alv;
        }
        else
            table[i] = nullptr;
    }

    return *this;
}






template <typename TYPECLE, typename TYPEVAL>
void hashdict<TYPECLE, TYPEVAL>::clear() {
    //ne supprimez pas bidon!
    if (table) {
        for (size_t i = 0; i < cap; i++) {
            if (table[i] && table[i] != bidon)
                delete table[i];
        }
        delete[] table;
        table = nullptr;
    }

    //il faut recréer une table pour futures insertions
    set_cap(10);
}








template <typename TYPECLE, typename TYPEVAL>
void hashdict<TYPECLE, TYPEVAL>::set_cap(size_t c) {
    //on suppose que c > 0
    //vous devez créer une nouvelle table ici.  Initialiser d'abord ses valeurs à nullptr,
    //puis ajoutez-y les valeurs de la table courante.
    //Normalement, on ne ferait que déplacer les alvéoles puisque ce sont des pointeurs.
    //Mais je vous permet d'appeler insert sur chaque ancien élément et ainsi de recréer chaque alvéole
    alveole** vieilleTable = table;
    size_t vieille_cap = cap;

    cap = c;
    table = new alveole * [cap];

    for (size_t i = 0; i < cap; i++)
        table[i] = nullptr;

    if (vieilleTable) {
        //copier elts et nettoyer
        for (size_t i = 0; i < vieille_cap; i++) {
            if (vieilleTable[i] && vieilleTable[i] != bidon) {
                //rappeler inserer est légèrement moins efficace, c'est un peu mieux de déplacer 
                //l'alvéole au lieu de la copier+supprimer.  Mais ici j'invoque l'argument de réutilisation de code.
                inserer(vieilleTable[i]->cle, vieilleTable[i]->val);

                delete vieilleTable[i];
            }
        }
        delete[] vieilleTable;
    }

}




template <typename TYPECLE, typename TYPEVAL>
bool hashdict<TYPECLE, TYPEVAL>::inserer(const TYPECLE& cle, const TYPEVAL& val) {
    if (contient_cle(cle))
        return false;

    if ((float)nbelem / (float)cap >= 0.5f) {   //serait mieux: 2 * nbelem >= cap, comme ça pas de conversion en float
        set_cap(cap * 2);
    }

    size_t h = get_position_cle(cle, true);
    table[h] = new alveole(cle, val);

    nbelem++;

    return true;
}


template <typename TYPECLE, typename TYPEVAL>
TYPEVAL& hashdict<TYPECLE, TYPEVAL>::operator[](const TYPECLE& cle) {
    if (!contient_cle(cle)) {
        TYPEVAL val;
        inserer(cle, val);
    }
    
    //à ce point-ci la clé est garantie d'exister
    size_t h = get_position_cle(cle);
    return table[h]->val;
}


template <typename TYPECLE, typename TYPEVAL>
bool hashdict<TYPECLE, TYPEVAL>::contient_cle(const TYPECLE& cle) const {
    size_t h = get_position_cle(cle);

    return (table[h] != nullptr);
}


template <typename TYPECLE, typename TYPEVAL>
size_t hashdict<TYPECLE, TYPEVAL>::get_position_cle(const TYPECLE& cle, bool arretSurBidon) const {
    size_t hcur = (std::hash<TYPECLE>()(cle) % cap);

    bool ok = false;

    //note: je ne gère pas le cas de la table 100% pleine pour boucle infinie, ce n'est pas censé arriver 
    //mais ce serait peut-être mieux de le vérifier
    while (!ok) {
        if (table[hcur] && table[hcur] != bidon && table[hcur]->cle == cle)
            ok = true;
        else if (table[hcur] == bidon && arretSurBidon)
            ok = true;
        else if (table[hcur]) {   //il y a quelque chose
            hcur = (hcur + 1) % cap;
        }
        else {    // !table[hcur]
            ok = true;
        }
    }

    return hcur;
}


template <typename TYPECLE, typename TYPEVAL>
bool hashdict<TYPECLE, TYPEVAL>::supprimer(const TYPECLE& cle) {
    //n'oubliez pas votre delete!
    if (!contient_cle(cle))
        return false;

    size_t h = get_position_cle(cle);

    delete table[h];

    table[h] = bidon;

    nbelem--;

    return true;
}









#endif // HASHDICT_H
